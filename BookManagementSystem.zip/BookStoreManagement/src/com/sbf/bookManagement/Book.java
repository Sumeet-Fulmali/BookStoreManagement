package com.sbf.bookManagement;

public class Book {
	private int bid;
	private String booksNames;
	private double bcost;

	public Book() {
		super();

	}

	public Book(int bid, String booksNames, double bcost) {
		super();
		this.bid = bid;
		this.booksNames = booksNames;
		this.bcost = bcost;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getBooksNames() {
		return booksNames;
	}

	public void setBooksNames(String booksNames) {
		this.booksNames = booksNames;
	}

	public double getBcost() {
		return bcost;
	}

	public void setBcost(double bcost) {
		this.bcost = bcost;
	}

	@Override
	public String toString() {
		return "Book [bid=" + bid + ", booksNames=" + booksNames + ", bcost=" + bcost + "]";
	}

	



}
