package com.sbf.bookManagement;

import java.util.Scanner;

public class BookOperation{
	 static double totbill;
	static  int choice,ch,qnt1,qnt2,qnt3,qnt4,totqnt;
	static double sgst,cgst,igst,gt;
		static double bill;
		
	public static void main(String[] args) {
		
		
		Scanner sc= new Scanner(System.in);
		
		Book [] b = new Book[4];
		b[0]= new Book(1, "The Lord of the Rings by J.R.R. Tolkien.",200);
		b[1]= new Book(2, "The Kite Runner by Khaled Hosseini.",300);
		b[2]= new Book(3, "Harry Potter and the Philosopher's Stone by J.K.Rollings",400);
		b[3]= new Book(4, "Slaughterhouse-Five by Kurt Vonnegut. ",500);
		do {
		System.out.println("Enter your choice....");
		
		System.out.println("1.The Lord of the Rings by J.R.R. Tolkien.");
		System.out.println("2.The Kite Runner by Khaled Hosseini.");
		System.out.println("3.Harry Potter and the Philosopher's Stone by J.K.Rollings");
		System.out.println("4.Slaughterhouse-Five by Kurt Vonnegut.");
		System.out.println("");
		ch = sc.nextInt();
		
		switch(ch) {
		case 1:{
			System.out.println("Enter the Quantity");
			qnt1 = sc.nextInt();
			if(qnt1>0) {
				bill=qnt1*b[0].getBcost();
			} else {
				throw new InvalidQuantityException("Enter valid quentity");
			}			
			totbill = bill;
			System.out.println("Bill : "+ bill );
		break;	
		}
		case 2 : {
			System.out.println("Enter the Quantity");
			qnt2 = sc.nextInt();
			if(qnt2>0) {
				bill=qnt2*b[1].getBcost();
			} else {
				throw new InvalidQuantityException("Enter valid quentity");
			}			
			totbill = totbill + bill;
			System.out.println("Bill : "+ bill );
		break;	
		}
		
		case 3 : {
			System.out.println("Enter the Quantity");
			qnt3 = sc.nextInt();
			if(qnt3>0) {
				bill=qnt3*b[2].getBcost();
			} else {
				throw new InvalidQuantityException("Enter valid quentity");
			}			
			totbill = totbill + bill;
			System.out.println("Bill : "+ bill );
		break;	
		}
			
		case 4 : {
			System.out.println("Enter the Quantity");
			qnt4 = sc.nextInt();
			if(qnt4>0) {
				bill=qnt4*b[3].getBcost();
			} else {
				throw new InvalidQuantityException("Enter valid quentity");
			}			
			totbill = totbill + bill;
			System.out.println("Bill : "+ bill );
		break;	
		}
			
		}
		System.out.println("Enter 1 to continue else 0");
		choice = sc.nextInt();
		  cgst = 12*totbill/100;
		  sgst = 5*totbill/100;
		  igst = 5*totbill/100;
		  gt = totbill+cgst+sgst+igst;
		  
	
		
		
	} while( choice==1);
		totqnt=qnt1+qnt2+qnt3+qnt4;
		System.out.println("---------------------------- ----------------------------------------------------------------------------");
		System.out.println("Book Name                         Quentity                 Price" );
			if(qnt1>0)
		System.out.println("---------------------------- ----------------------------------------------------------------------------");
		System.out.println("The Lord of the Rings                "  +qnt1+  "                     " + b[0].getBcost()*qnt1);
			if(qnt2>0)
		System.out.println("The Kite Runner                      "  +qnt2+  "                     " + b[1].getBcost()*qnt2);
			if(qnt3>0)
		System.out.println("Harry Potter and the                 "  +qnt3+  "                     " + b[2].getBcost()*qnt3);
		if(qnt4>0)
		System.out.println("Slaughterhouse-Five                  "  +qnt4+  "                     " + b[3].getBcost()*qnt4);
		System.out.println("----------------------------------------------------------------------------------------------------------");
		System.out.println("Total Bill                           " +totqnt+"                     "          +totbill);
		System.out.println("                                            CGST@12% =     " +cgst);
		System.out.println("                                            SGST@05% =     " +sgst);
		System.out.println("                                            IGST@05% =     " +igst);
		System.out.println("------------------------------------------------------------------------------------------------------------");
		System.out.println("Grand Total                                                "+gt);
		System.out.println("------------------------------------------------------------------------------------------------------------");
		sc.close();
}
}
